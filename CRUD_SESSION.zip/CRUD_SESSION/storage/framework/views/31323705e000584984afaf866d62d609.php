<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
  <div class="container">
    <h2 class="font-weight-bold text-center mt-3 mb-3">CREATE SESSION CRUD</h2>
  <form action="<?php echo e(route('createpost')); ?>" method="post">
    <?php echo csrf_field(); ?>
  <label for="" class="form-label">Name</label>
  <input type="text" class="form-control" name="name" id="">

  <label for="" class="form-label mt-4">Roll</label>
  <input type="text" name="roll" class="form-control" id="">

  <label for="" class="form-label mt-4">Address</label>
  <textarea name="address" id="" class="form-control" rows="3"></textarea>

  <div class="d-grid gap-2">
  <button class="btn btn-primary mt-3">Create</button>
  </div>

  </form>   

  </div>

  </body>
</html><?php /**PATH /home/kartikghosh4411/Desktop/SESSION/CRUD_SESSION/resources/views/CRUD/create.blade.php ENDPATH**/ ?>