<!doctype html>
<html lang="en">
  <head>
    <title>SESSION CRUD</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  </head>
  <body>
      <div class="container">
      <h2 class="text-center mt-3 mb-3 font-weight-bold">SESSION CRUD</h2>
      <div class="d-flex justify-content-center mb-5">
      <a href="{{ route('create') }}"><button class="btn btn-success">CREATE</button></a>
      </div>

      <!-- Session message start here -->
        @if(session()->has('success')) <!--it's create message--> 
            <div class="alert alert-success alert-dismissible">
                {{session()->get('success')}}
                <button class="btn-close" data-bs-dismiss="alert"></button>
            </div>

            @elseif(session()->has('deletesuccess')) <!--it's delete message--> 
                <div class="alert alert-danger alert-dismissible">
                        {{session()->get('deletesuccess')}}
                        <button class="btn-close" data-bs-dismiss="alert"></button>
                    </div>

            @elseif(session()->has('updatesuccess')) <!--it's update message--> 
                <div class="alert alert-primary alert-dismissible">
                        {{session()->get('updatesuccess')}}
                        <button class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
        @endif

        <!-- Session message start end -->

    <table class="table">
        <thead>
            <tr>
                <th>Name</th>
                <th>Roll</th>
                <th>Address</th>
                <th>Delete</th>
                <th>Update</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                @if(session()->has(['name','roll','address']))
                    <td>{{session()->get('name')}}</td>
                    <td>{{session()->get('roll')}}</td>
                    <td>{{session()->get('address')}}</td>
                    <th><a href="{{ route('DeletePage') }}"><button class="btn btn-danger">Delete</button></a></th>
                    <th><a href="{{ route('update') }}"><button class="btn btn-primary">Update</button></a></th>
                @endif
            </tr>
        </tbody>
    </table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>

  </body>
</html>