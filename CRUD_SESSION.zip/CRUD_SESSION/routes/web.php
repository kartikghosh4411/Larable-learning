<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SesssionCrudController;

//data show route
Route::get('/',[SesssionCrudController::class,'HomePage'])->name('home'); //GET ROUTE

//data create route
Route::get('create/',[SesssionCrudController::class,'CretePage'])->name('create'); //GET ROUTE
Route::post('create/',[SesssionCrudController::class,'CretePagePost'])->name('createpost'); //POST ROUTE

//data update route
Route::get('update/',[SesssionCrudController::class,'UpdatePage'])->name('update'); //GET ROUTE
Route::post('update/',[SesssionCrudController::class,'UpdatePagePost'])->name('UpdatePagePost'); //POST ROUTE

//data delete route
Route::get('delete/',[SesssionCrudController::class, 'DeletePage'])->name('DeletePage'); //GET ROUTE
