<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SesssionCrudController extends Controller
{
    public function HomePage(){ //data show function GET
        return view('CRUD/index');
    }

    public function CretePage(){ //data create function GET
        return view('CRUD/create');
    }

    public function CretePagePost(request $request){ //data create function POST
        $request->validate([
            'name'    => 'required',
            'roll'    => 'required',
            'address' => 'required',
        ]);

        $name    = $request['name'];
        $roll    = $request['roll'];
        $address = $request['address'];

        session()->put('name',$name);
        session()->put('roll',$roll);
        session()->put('address',$address);

        //message display session here
        $message = session()->flash('success','Session Create Succesfully');

        return redirect()->route('home')->with($message);
    }

    public function UpdatePage(){ //data update function GET
        return view('CRUD/update');
    }

    public function UpdatePagePost(request $request){ //data update function POST
        $request->validate([
            'name'    => 'required',
            'roll'    => 'required',
            'address' => 'required',
        ]);

        $name       = $request['name'];
        $roll       = $request['roll'];
        $address    = $request['address'];

        session()->put('name',$name);
        session()->put('roll',$roll);
        session()->put('address',$address);

        //message display session here
        $message = session()->flash('updatesuccess','Data Update Successfully');

        return redirect()->route('home')->with($message);
    }

    public function DeletePage(){ //data delete function GET
        session()->forget('name');
        session()->forget('roll');
        session()->forget('address');

        //message display session here
        $message = session()->flash('deletesuccess','Data Delete Successfully');

        return redirect()->route('home')->with($message);
    }
}
