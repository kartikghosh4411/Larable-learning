<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ImangeController;

Route::get('/',[ImangeController::class,'index']); //GET REQUEST ROUTE HERE
Route::post('/',[ImangeController::class,'images']); //POST REQUEST ROUTE HERE
