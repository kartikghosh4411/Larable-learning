<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bootstrap Site</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css" integrity="sha384-r4NyP46KrjDleawBgD5tp8Y7UzmLA05oM1iAEQ17CSuDqnUK2+k9luXQOfXJCJ4I" crossorigin="anonymous">
 
</head>
<body>

<!-- CONTAINER DIV HERE  -->
<div class="container">

<h1 class="my-3 font-weight-bold">UPLOAD FROM</h1>

<!-- IMAGE FROM HERE START -->
<form action="{{ url('/') }}" method="post" enctype="multipart/form-data">
    @csrf
    <!-- ROW DIV HERE  -->
    <div class="row">
        <div class="col-6">
            <input type="file" name="image[]" id="" class="form-control" multiple>
        </div>

        <div class="col-6">
            <button type="submit" class="btn btn-primary">Upload</button>
        </div>
        
        <!-- FROM BLANK OR NOT MESSAGE HERE  -->
        <div class="col-6">
            @if(session()->get('ferror'))
            <div class="form-text text-danger">{{session()->get('ferror')}}</div>
            @endif
        </div>
        <!-- FROM BLANK OR NOT MESSAGE END -->
    </div>
    <!-- ROW DIV END -->



        <!-- SHOW IMAGE IN SESSION   -->
        @if(session()->get('imgview'))
        @foreach(session()->get('imgview') as $imgviews)
            <div>
                <img src="upload/{{$imgviews}}" alt="" srcset="">
            </div>
        @endforeach
        @endif
        <!-- END IMAGE IN SESSION -->

        <!-- OTHER FILE NOT ALLOWED ONLY RECEIVED IMAGE CODE HERE -->
        @error('image.*')
        <div class="form-text text-danger">Only Upload Image Not Other File</div>
        @enderror
        <!-- OTHER FILE NOT ALLOWED ONLY RECEIVED IMAGE CODE END -->



</form>
<!-- IMAGE FROM HERE END  -->

</div>
<!-- CONTAINER DIV END -->

<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js" integrity="sha384-oesi62hOLfzrys4LxRF63OJCXdXDipiYWBnvTl9Y9/TRlw5xlKIEHpNyvvDShgf/" crossorigin="anonymous"></script>
</body>
</html>