<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Image;

class ImangeController extends Controller
{
    //Image Template Show -- 001
    public function index(){ //GET REQUEST
        return view('image');
    } //GET REQUEST END

    //Image Form Submition -- 002
    public function images(request $request){ //POST REQUEST

        //IMAGE VALIDATION CODE HERE
        $request->validate([
            'image.*' => ['required',
            'image',
            'mimes:jpg,png,jpeg,gif,svg',]
        ]);
        //IMAGE VALIDATION CODE END


        //IMAGE REQUEST RECEIVED HERE
        $img = $request['image'];
        //IMAGE REQUEST RECEIVED END
        
        if(!is_null($img)) // CHECK IMAGE BLANK OR NOT IF CONDITION
        {


            //IMAGE SAVE IN PUBLIC FOLDER HERE
            foreach($img as $imgss)
            {
                $ImageName = time().rand(0,1000).'.'.$imgss->extension(); //IMAGE CUSTOM NAME CODE
                $ImageSave = $imgss->move(public_path('upload'),$ImageName); //IMAGE SAVE IN PUBLIC FOLDER CODE

                $imgview[] = $ImageName; //SEND IMAGE IN ARRAY FROM
            }
            //IMAGE SAVE IN PUBLIC FOLDER END


            
            //IMAGE SAVE IN DATABASE CODE HERE
            foreach($imgview as $imgmod)
            {
                $ImageModel = new Image;
                $ImageModel->image = $imgmod;
                $ImageModel->save();
            }
            //IMAGE SAVE IN DATABASE CODE END

            return redirect()->back()->with('imgview',$imgview);
        } // END IF CONDITION

        else{ //ELSE CONDITION
            $messag = session()->flash('ferror','image field is required');
            return redirect('/')->with('messag',$messag);
        } //END ELSE CONDITION
        

    } //POST ReQUEST FUNCTION END
}
