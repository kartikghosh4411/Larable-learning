<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CrudController;

Route::get('/', function () {
    return view('welcome');
});

//data create route here start
Route::get('create/',[CrudController::class,'create_function'])->name('create_function'); //get request
Route::post('create/',[CrudController::class,'create_function_post'])->name('create_function_post'); //post request
//data create route here end

//data read function here start
Route::get('read/',[CrudController::class,'read_function'])->name('read_function');//get request
//data read function here end

//data delete function here start
Route::get('delete/{id}',[CrudController::class,'delete_function'])->name('delete_function'); //get request
//data delete function here end

//data update function here start
Route::get('update/{id}',[CrudController::class,'update_function'])->name('update_function'); //get request
Route::post('update/{id}',[CrudController::class,'update_function_post'])->name('update_function_post'); //post request
//data update function here end
