<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Crud;

class CrudController extends Controller
{
    //CREATE function GET request (INSERT QUERY)
    public function create_function()
    {
        return view('Crud/create');
    }

    //CREATE function POST request (INSERT QUERY)
    public function create_function_post(request $request)
    {
        $request->validate([
            'name' => 'required',
            'address' => 'required',
            'phone' => 'required',
        ]);

        $cruds = new Crud;
        $cruds->Name = $request['name'];
        $cruds->Address = $request['address'];
        $cruds->Phone = $request['phone'];
        $cruds->save();
        return redirect()->route('read_function');
    }

    //READ function GET request (SELECT QUERY)
    public function read_function()
    {
        $readCrud = Crud::all();
        $data = compact('readCrud');
        return view('Crud/read')->with($data);
    }

    //DELETE function GET request (DELETE QUERY)
    public function delete_function($id)
    {
        $Del = Crud::find($id);
        if(!is_null($Del)){
            $Del->delete();
            return redirect()->route('read_function');
        }

        else
        {
            return redirect()->route('read_function');
        }

    }

    //UPDATE function GET request (UPDATE QUERY)
    public function update_function($id){
        $updatedata = Crud::find($id);
        if(!is_null($updatedata))
        {
            return view('Crud/update',['updatedata'=>$updatedata]);
        }

        else 
        {
            return redirect()->route('read_function');
        }
        
    }


    //UPDATE function POST request (UPDATE QUERY)
    public function update_function_post($id, request $request_update){
            $request_update->validate([
                'name' => 'required',
                'address' => 'required',
                'phone' => 'required',
            ]);

            $crud_data = Crud::find($id);
            $crud_data->Name = $request_update['name'];
            $crud_data->Address = $request_update['address'];
            $crud_data->Phone = $request_update['phone'];
            $crud_data->save();

            return redirect()->route('read_function');
    }
}
