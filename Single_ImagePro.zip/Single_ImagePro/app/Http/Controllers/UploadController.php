<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ImageUpload;

class UploadController extends Controller
{
    public function uploadget(){
        return view('upload');
    }

    public function uploadpost(request $request){
        $request->validate([
            'image' => ['required',
            'image',
            'mimes:jpg,png,jpeg,gif,svg',
            'dimensions:min_width=100,min_height=100,max_width=1000,max_height=1000',
            'max:2048']
        ]);

        $img = $request['image'];
        
        //Name change in image
        $imgext = time().'-durjoy.'.$img->extension();
    
        // save image in public folder
        $img->move(public_path('images'),$imgext);


        //save image in database
        $ImageSave = new ImageUpload;
        $ImageSave->imageupload = $imgext;
        $ImageSave->save();
        return back()->with('ImageName',$imgext);

    }
}
