<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>

    <div class="container">
    <!-- <h2 class="font-weight-bold">Laravel 10 Kartik Chandra Ghosh</h2> -->
    <div class="panel-heading"><h2>Laravel 10 Kartik Chandra Ghosh</h2></div>

    @if(Session::get('ImageName'))
    <img src="images/{{ Session::get('ImageName') }}">
    @endif

    <form action="{{ route('uploadpost') }}" method="post" enctype="multipart/form-data">
        @csrf
    <div class="row">

        <div class="col-md-6"><input type="file" class="form-control" name="image" id=""></div>
        <div class="col-md-6"><button type="submit" class="btn btn-success">Upload</button></div>
    </div>
    </form>
    
    </div>

  </body>
</html>