<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UploadController;

Route::get('/', function () {
    return view('welcome');
});

Route::get('upload/', [UploadController::class,'uploadget'])->name('uploadget');
Route::post('upload/', [UploadController::class,'uploadpost'])->name('uploadpost');
